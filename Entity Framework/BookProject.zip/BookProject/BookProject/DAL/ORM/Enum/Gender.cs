﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookProject.DAL.ORM.Enum
{
    public enum Gender
    {
        None=0,
        Female=1,
        Male=2,
        Others=3
    }
}
