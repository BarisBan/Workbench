﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookProject.DAL.ORM.Enum
{
    public enum Status
    {
        None = 0,
        Active =1,
        Updated =2,
        Deleted =3
    }
}
